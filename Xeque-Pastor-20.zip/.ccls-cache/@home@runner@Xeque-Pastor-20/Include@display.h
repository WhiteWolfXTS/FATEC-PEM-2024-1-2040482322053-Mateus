#ifndef DISPLAY_H
#define DISPLAY_H

void exibirTabuleiro(char tabuleiro[MAXLIN][MAXCOL][4]);

#endif