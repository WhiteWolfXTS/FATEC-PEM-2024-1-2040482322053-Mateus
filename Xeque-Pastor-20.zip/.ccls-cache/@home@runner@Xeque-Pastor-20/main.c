#include "board.h"

int main(void) {
    criarTabuleiro();
    return 0;
}