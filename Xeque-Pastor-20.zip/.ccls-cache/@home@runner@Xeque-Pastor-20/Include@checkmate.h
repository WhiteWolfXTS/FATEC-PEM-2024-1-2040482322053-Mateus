#ifndef CHECKMATE_H
#define CHECKMATE_H

void xequePastor(char tabuleiro[MAXLIN][MAXCOL][4]);

#endif