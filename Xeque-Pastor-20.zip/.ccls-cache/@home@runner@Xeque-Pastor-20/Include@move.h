#ifndef MOVE_H
#define MOVE_H

void jogada(int origem[2], int destino[2], char tabuleiro[MAXLIN][MAXCOL][4]);

#endif