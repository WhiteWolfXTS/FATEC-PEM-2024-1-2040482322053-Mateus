#ifndef BOARD_H
#define BOARD_H

#define MAXLIN 8
#define MAXCOL 8

void criarTabuleiro(void);

#endif